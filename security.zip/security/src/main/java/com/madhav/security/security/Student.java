package com.madhav.security.security;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Student {

    @GetMapping("/user")
    public String getname(){
        return "madhav is good boy";
    }
}
